typedef struct con_t;
double ex03b(con_t *con, double isig);

