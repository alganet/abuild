function y = doit(x)
  state(0) = state(0);
  state(0) = fctn(0);
end
