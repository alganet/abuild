function j = ex01a(k)
   j = k;
   for i = 1:100
      j = j + 1;
   end
end
