
int foo(int k) {
  int i;
  for (i = 0; ; i++)  {
    k = k + 1;
  }
  return k;
}
