
int foo(int k) {
  for (int i = 0; i < 3; i++) {
     k += i;
  }
  return k;
}
