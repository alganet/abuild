//

typedef struct {
  int a[23],c[13]; /* this is a and c */
  int *b; /* this is b */
  double d[10];
} foo_t;

foo_t abc;
