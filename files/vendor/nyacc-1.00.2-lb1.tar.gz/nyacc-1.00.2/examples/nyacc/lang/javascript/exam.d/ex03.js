function myref(ooa, ix) { return ooa[ix]; }
var point = { x:3, y:4 }
var array = [ 1,,, 2, 3 ]
//myref(point, "x") + 0
myref(array, 4) + 0
