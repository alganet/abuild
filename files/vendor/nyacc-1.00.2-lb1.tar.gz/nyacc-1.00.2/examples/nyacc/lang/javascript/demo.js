var a = 1;

function foo(x) {
  var y = 2;
  return x + y;
}

