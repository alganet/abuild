var x = 1;
do { 
  display(x); newline();
  x = x + 1;
} while (x < 10);
while (x > 0) {
  display(x); newline();
  x = x - 1;
} 
