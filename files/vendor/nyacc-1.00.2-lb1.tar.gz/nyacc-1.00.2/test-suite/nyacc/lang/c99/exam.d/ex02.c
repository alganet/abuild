//
/* hello */
#define XYZ 1 /*
  lame comment 
 */
int x; /* hello */

int /* zoo */ foo /* z */(/* t */ int /* comment */ x) /* x */ {
  int /* hello */ y /* 8 */ = /* 9 */ 3;
  return /* 1 */ x /* 2 */ + /* 3 */ y /* 4 */; /* 5 */
}
