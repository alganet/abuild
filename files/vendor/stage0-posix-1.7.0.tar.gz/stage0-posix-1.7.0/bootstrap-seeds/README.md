Here are the bare minimal binary seeds for every host architecture

*NEVER TRUST ANYTHING IN HERE*

you have been warned

    hex0 can be approximated with: sed 's/[;#].*$//g' $input_file | xxd -r -p > $output_file
    kaem-optional-seed can be replaced by any shell of your choice as it is just a minimal shell written in hex0

It is assumed that you should replace this with something you personally audited and trust.