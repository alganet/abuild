Inside is a standard C library for those who need to bootstrap from nothing.
As all of the pieces inside will work with M2-Planet and mescc-tools